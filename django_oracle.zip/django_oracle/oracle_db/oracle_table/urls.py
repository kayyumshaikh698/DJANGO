from django.urls import path 
from . import views

urlpatterns = [
    # path("", views.studentdetail.as_view()),
    # path("user_output", views.table_detail.as_view())
    # path("sqlquery", views.sql_query, name="sql-query"),
    path("now", views.sql,name="sql")
]
