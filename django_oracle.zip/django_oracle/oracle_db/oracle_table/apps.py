from django.apps import AppConfig


class OracleTableConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'oracle_table'
