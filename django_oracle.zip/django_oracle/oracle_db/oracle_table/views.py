from django.db import DatabaseError, connection
from django.shortcuts import render
# from .models import Studentdata
from oracledb import *
# from .forms import sqlForm

def sql(request):
    # connecting to oracle database 19c 
        if request.method == "POST" :
        #  forms = sqlForm.cleaned_data["sql_query"]
         query = request.POST["sql_query"]
         with connection.cursor() as cursor:
                cursor.execute(f"{query};")
                rows = cursor.fetchall()
                return render(request, "oracle_table/sql_result.html", {"data" : rows})
        else:
             return render(request, "oracle_table/sql_sample.html")

# def sql_query(request):
#         name = Studentdata.objects.all()
#         return render(request, "oracle_table/sql_result.html",{
#             "result" : name
#         })


# from .models import Studentdata
# from django.views.generic.edit import CreateView
# from django.views.generic import ListView

# # Create your views here.

# class studentdetail(CreateView):
#     template_name = "oracle_table/table.html"
#     model = Studentdata
#     fields = "__all__"
#     success_url = "/user_output"

# class table_detail(ListView):
#     model = Studentdata
#     template_name = "oracle_table/user_output.html"
#     context_object_name = "tables"