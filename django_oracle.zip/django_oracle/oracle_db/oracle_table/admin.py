from django.contrib import admin
# from .models import Studentdata

# Register your models here.
# admin.site.register(Studentdata)