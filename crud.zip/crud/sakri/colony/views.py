from django.http import Http404, HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, render
from .models import GeeksModel
from .forms import GeeksForm
# Create your views here.

def create_view(request):
    context = {}
    form = GeeksForm(request.POST or None)
    if form.is_valid():
        form.save()
    context['form'] = form 
    return render(request, "create_view.html",context)

# list view 
def list_view(request):
    context = {}
    context["dataset"] = GeeksModel.objects.all()
    return render(request, "list_view.html", context)

# detail view 
def detail_view(request, id):
    try:
        context = {}
        context["data"] = GeeksModel.objects.get(id=id)
        return render(request, "detail_view.html", context)
    except :
        return HttpResponse("invalid id")
    
# update view
def update_view(request, id):
    context = {}
    obj = get_object_or_404(GeeksModel, id=id)
    form = GeeksForm(request.POST or None, instance=obj)
    if form.is_valid():
        form.save()
        return HttpResponseRedirect("/update/"+ str(id))
    context["form"] = form 
    return render(request, "update_view.html", context)

# delete view 
def delete_view(request, id):
    context = {}
    obj = get_object_or_404(GeeksModel, id=id)
    if request.method == "POST" :
        obj.delete()
        return HttpResponseRedirect("/")
    return render(request, "delete_view.html", context)